/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository.impl;

import domainModel.PhuKienNCC;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import repository.IPhuKienNCCRepository;
import util.HibernateUtil;

/**
 *
 * @author Admin
 */
public class PhuKienNCCRepository implements IPhuKienNCCRepository {

    @Override
    public List<PhuKienNCC> getAll() {
        List<PhuKienNCC> list;
        try ( Session session = HibernateUtil.getFACTORY().openSession()) {
            Query q = session.createQuery("FROM PhuKienNCC");
            list = q.getResultList();
            return list;
        } catch (Exception e) {
            e.printStackTrace(System.out);
            return null;
        }
    }

    @Override
    public boolean save(PhuKienNCC pkNcc) {
        Transaction tran = null;
        try ( Session session = HibernateUtil.getFACTORY().openSession()) {
            tran = session.beginTransaction();
            session.save(pkNcc);
            tran.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace(System.out);
            tran.rollback();
            return false;
        }
    }

    @Override
    public boolean update(PhuKienNCC pkNcc) {
        Transaction tran = null;
        try ( Session session = HibernateUtil.getFACTORY().openSession()) {
            tran = session.beginTransaction();
            session.update(pkNcc);
            tran.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace(System.out);
            tran.rollback();
            return false;
        }
    }

    @Override
    public boolean delete(PhuKienNCC pkNcc) {
        Transaction tran = null;
        try ( Session session = HibernateUtil.getFACTORY().openSession()) {
            tran = session.beginTransaction();
            session.delete(pkNcc);
            tran.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace(System.out);
            tran.rollback();
            return false;
        }
    }

}
