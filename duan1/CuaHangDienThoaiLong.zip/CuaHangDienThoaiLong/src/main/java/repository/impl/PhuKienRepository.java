/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository.impl;

import domainModel.PhuKien;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import repository.IPhuKienRepository;
import util.HibernateUtil;

/**
 *
 * @author Admin
 */
public class PhuKienRepository implements IPhuKienRepository {

    @Override
    public List<PhuKien> getAll() {
        List<PhuKien> list;
        try ( Session session = HibernateUtil.getFACTORY().openSession()) {
            Query q = session.createQuery("SELECT pk FROM PhuKien pk");
            list = q.getResultList();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            return null;
        }
        return list;
    }

    @Override
    public PhuKien getOne(String ma) {
        try ( Session session = HibernateUtil.getFACTORY().openSession()) {
            Query q = session.createQuery(" From PhuKien"
                    + " Where ma = :ma");
            q.setParameter("ma", ma);
            PhuKien pk = (PhuKien) q.getSingleResult();
            return pk;
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return null;
    }
    
    public static void main(String[] args) {
        PhuKien pk = new PhuKienRepository().getOne("PK00");
    }

}
