/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package services;


import java.util.List;
import viewModel.QLHang;

/**
 *
 * @author Admin
 */
public interface IHangService {
    
    List<QLHang> getHHD();
    
    List<QLHang> getHNHD();
    
    List<QLHang> timKiem(String chuoi, int number);
    
    String save(QLHang hang);
    
    String update(QLHang hang);
    
    String delete(QLHang hang);
    
}
