/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services.impl;

import domainModel.NhaCungCap;
import domainModel.PhuKien;
import domainModel.PhuKienNCC;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import repository.IPhuKienNCCRepository;
import repository.impl.PhuKienNCCRepository;
import services.IPhuKienNCCService;
import viewModel.QLNhaCungCap;
import viewModel.QLPhuKien;
import viewModel.QLPhuKienNCC;

/**
 *
 * @author Admin
 */
public class PhuKienNCCService implements IPhuKienNCCService {

    private IPhuKienNCCRepository phuKienNCCRep = new PhuKienNCCRepository();

    @Override
    public List<QLPhuKienNCC> getAll() {
        List<QLPhuKienNCC> list = new ArrayList<>();
        for (PhuKienNCC x : phuKienNCCRep.getAll()) {
            QLNhaCungCap ncc = new QLNhaCungCap(x.getNhaCungCap().getId(), x.getNhaCungCap().getMa(), null, x.getNhaCungCap().getTen(), null, null, 0);
            QLPhuKien pk = new QLPhuKien(x.getPhuKien().getId(), x.getPhuKien().getMa(), x.getPhuKien().getTen(), 0, BigDecimal.valueOf(0.0), null, 0, null, 0, null);
            QLPhuKienNCC pkNcc = new QLPhuKienNCC(x.getId(), ncc, pk, x.getGiaNhap(), x.getSoLuongNhap(), x.getNgayNhap());
            list.add(pkNcc);
        }
        return list;
    }

    @Override
    public String save(QLPhuKienNCC pkNcc) {
        NhaCungCap ncc = new NhaCungCap(pkNcc.getNhaCungCap().getId(), pkNcc.getNhaCungCap().getMa(), null, pkNcc.getNhaCungCap().getTen(), null, null, 0, null);
        PhuKien pk = new PhuKien(pkNcc.getPhuKien().getId(), pkNcc.getPhuKien().getMa(), pkNcc.getPhuKien().getTen(), 0, BigDecimal.valueOf(0.0), null, 0, null, 0, null, null);
        PhuKienNCC newPkNcc = new PhuKienNCC(null, ncc, pk, pkNcc.getGiaNhap(), pkNcc.getSoLuongNhap(), pkNcc.getNgayNhap());
        if(phuKienNCCRep.save(newPkNcc)){
            return "Them thanh cong";
        }else{
            return "Them that bai";
        }
    }

    @Override
    public String update(QLPhuKienNCC pkNcc) {
        NhaCungCap ncc = new NhaCungCap(pkNcc.getNhaCungCap().getId(), pkNcc.getNhaCungCap().getMa(), null, pkNcc.getNhaCungCap().getTen(), null, null, 0, null);
        PhuKien pk = new PhuKien(pkNcc.getPhuKien().getId(), pkNcc.getPhuKien().getMa(), pkNcc.getPhuKien().getTen(), 0, BigDecimal.valueOf(0.0), null, 0, null, 0, null, null);
        PhuKienNCC newPkNcc = new PhuKienNCC(pkNcc.getId(), ncc, pk, pkNcc.getGiaNhap(), pkNcc.getSoLuongNhap(), pkNcc.getNgayNhap());
        if(phuKienNCCRep.update(newPkNcc)){
            return "Sua thanh cong";
        }else{
            return "Sua that bai";
        }
    }

    @Override
    public String delete(QLPhuKienNCC pkNcc) {
        NhaCungCap ncc = new NhaCungCap(pkNcc.getNhaCungCap().getId(), pkNcc.getNhaCungCap().getMa(), null, pkNcc.getNhaCungCap().getTen(), null, null, 0, null);
        PhuKien pk = new PhuKien(pkNcc.getPhuKien().getId(), pkNcc.getPhuKien().getMa(), pkNcc.getPhuKien().getTen(), 0, BigDecimal.valueOf(0.0), null, 0, null, 0, null, null);
        PhuKienNCC newPkNcc = new PhuKienNCC(pkNcc.getId(), ncc, pk, pkNcc.getGiaNhap(), pkNcc.getSoLuongNhap(), pkNcc.getNgayNhap());
        if(phuKienNCCRep.delete(newPkNcc)){
            return "Xoa thanh cong";
        }else{
            return "Xoa that bai";
        }
    }

}
