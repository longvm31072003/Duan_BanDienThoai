/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository.impl;

import domainModel.NhaCungCap;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import repository.INhaCungCapRepository;
import util.HibernateUtil;

/**
 *
 * @author Admin
 */
public class NhaCungCapRepository implements INhaCungCapRepository {

    @Override
    public List<NhaCungCap> getAll() {
        List<NhaCungCap> list;
        try ( Session session = HibernateUtil.getFACTORY().openSession()) {
            Query q = session.createQuery("FROM NhaCungCap");
            list = q.getResultList();
            return list;
        } catch (Exception e) {
            e.printStackTrace(System.out);
            return null;
        }
    }

    @Override
    public boolean save(NhaCungCap nhaCungCap) {
        Transaction tran = null;
        try ( Session session = HibernateUtil.getFACTORY().openSession()) {
            tran = session.beginTransaction();
            session.save(nhaCungCap);
            tran.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace(System.out);
            tran.rollback();
            return false;
        }
    }

    @Override
    public boolean update(NhaCungCap nhaCungCap) {
        Transaction tran = null;
        try ( Session session = HibernateUtil.getFACTORY().openSession()) {
            tran = session.beginTransaction();
            session.update(nhaCungCap);
            tran.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace(System.out);
            tran.rollback();
            return false;
        }
    }

    @Override
    public boolean delete(NhaCungCap nhaCungCap) {
        Transaction tran = null;
        try ( Session session = HibernateUtil.getFACTORY().openSession()) {
            tran = session.beginTransaction();
            session.delete(nhaCungCap);
            tran.commit();
            return true;
        } catch (Exception e) {
            e.printStackTrace(System.out);
            tran.rollback();
            return false;
        }
    }

}
