/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository.impl;

import domainModel.KhachHang;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import util.HibernateUtil;
import repository.IKhachHangRepository;

/**
 *
 * @author Admin
 */
public class KhachHangRepository implements IKhachHangRepository{

    @Override
    public List<KhachHang> getAll() {
        List<KhachHang> list = new ArrayList<>();
        try ( Session session = HibernateUtil.getFACTORY().openSession()) {
            Query q = session.createQuery("FROM KhachHang");
            list = q.getResultList();
        } catch (Exception e) {
            e.printStackTrace(System.out);
            return null;
        }
        return list;
    }

    @Override
    public KhachHang getOne(String ma) {
        try ( Session session = HibernateUtil.getFACTORY().openSession()) {
            Query q = session.createQuery(" From KhachHang"
                    + " Where cccd = :cccd");
            q.setParameter("cccd", ma);
            KhachHang kh = (KhachHang) q.getSingleResult();
            return kh;
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return null;
    } 
    
}
