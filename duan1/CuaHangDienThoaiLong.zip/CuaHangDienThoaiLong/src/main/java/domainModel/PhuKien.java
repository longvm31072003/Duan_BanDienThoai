/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domainModel;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;

/**
 *
 * @author Admin
 */
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Table(name = "PhuKien")
public class PhuKien implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Type(type = "uuid-char")
    @Column(name = "IDPhuKien")
    private UUID id;
    
    @Column(name = "MaPhuKien")
    private String ma;
    
    @Column(name = "TenPhuKien")
    private String ten;
    
    @Column(name = "SoLuong")
    private int soLuong;
    
    @Column(name = "GiaBan")
    private BigDecimal giaBan;
    
    @Column(name = "Anh", nullable = true)
    private String anh;
    
    @Column(name = "ThoiGianBaoHanh")
    private int thoiGianBaoHanh;
    
    @Column(name = "MoTa")
    private String moTa;
    
    @Column(name = "TrangThai")
    private int trangThai;
    
    @ManyToOne
    @JoinColumn(name = "IDHang")
    private Hang hang;
    
    @OneToMany(mappedBy = "phuKien", fetch = FetchType.LAZY)
    private List<PhuKienNCC> listPhuKienNCC;
    
}
