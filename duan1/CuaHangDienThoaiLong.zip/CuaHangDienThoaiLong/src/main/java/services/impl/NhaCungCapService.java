/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services.impl;

import domainModel.NhaCungCap;
import java.util.ArrayList;
import java.util.List;
import repository.INhaCungCapRepository;
import repository.impl.NhaCungCapRepository;
import services.INhaCungCapService;
import viewModel.QLNhaCungCap;

/**
 *
 * @author Admin
 */
public class NhaCungCapService implements INhaCungCapService {

    private INhaCungCapRepository nhaCungCapRep = new NhaCungCapRepository();

    @Override
    public List<QLNhaCungCap> getAll() {
        List<QLNhaCungCap> list = new ArrayList<>();
        for (NhaCungCap x : nhaCungCapRep.getAll()) {
            QLNhaCungCap newNcc = new QLNhaCungCap(x.getId(), x.getMa(), x.getDiaChi(), x.getTen(), x.getSdt(), x.getEmail(), x.getTrangThai());
            list.add(newNcc);
        }
        return list;
    }

    @Override
    public String save(QLNhaCungCap ncc) {
        NhaCungCap newNcc = new NhaCungCap(null, ncc.getMa(), ncc.getDiaChi(), ncc.getTen(), ncc.getSdt(), ncc.getEmail(), ncc.getTrangThai(), null);
        if (nhaCungCapRep.save(newNcc)) {
            return "Them thanh cong";
        } else {
            return "Them that bai";
        }
    }

    @Override
    public String update(QLNhaCungCap ncc) {
        NhaCungCap newNcc = new NhaCungCap(ncc.getId(), ncc.getMa(), ncc.getDiaChi(), ncc.getTen(), ncc.getSdt(), ncc.getEmail(), ncc.getTrangThai(), null);
        if (nhaCungCapRep.update(newNcc)) {
            return "Sua thanh cong";
        } else {
            return "Sua that bai";
        }
    }

    @Override
    public String delete(QLNhaCungCap ncc) {
        NhaCungCap newNcc = new NhaCungCap(ncc.getId(), ncc.getMa(), ncc.getDiaChi(), ncc.getTen(), ncc.getSdt(), ncc.getEmail(), ncc.getTrangThai(), null);
        if (nhaCungCapRep.delete(newNcc)) {
            return "Xoa thanh cong";
        } else {
            return "Xoa that bai";
        }
    }

}
