/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domainModel;

import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Table(name = "KhachHang")
public class KhachHang implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "Id", length = 36)
    private UUID id;
    
    @Column(name = "CCCD")
    private String cccd;
    
    @Column(name = "NamSinh")
    private int namSinh;
    
    @Column(name = "Sdt")
    private int sdt;
    
    @Column(name = "Email")
    private String email;
    
    @Column(name = "DiaChi")
    private String diaChi;
    
    @Column(name = "DiemTichLuy")
    private int DiemTichLuy;
    
    @Column(name = "GioiTinh")
    private int gioiTinh;
    
}
