/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services.impl;

import domainModel.KhachHang;
import java.util.ArrayList;
import java.util.List;
import repository.IKhachHangRepository;
import repository.impl.KhachHangRepository;
import services.IKhachHangService;
import viewModel.QLKhachHang;

/**
 *
 * @author Admin
 */
public class KhachHangService implements IKhachHangService{

    IKhachHangRepository khachHangRep = new KhachHangRepository();
    
    @Override
    public List<QLKhachHang> getAll() {
        List<QLKhachHang> listKhachHang = new ArrayList<>();
        for (KhachHang x : khachHangRep.getAll()) {
            QLKhachHang khachHang = new QLKhachHang(x.getId(), x.getCccd(), x.getNamSinh(), x.getSdt(), 
                    x.getEmail(), x.getDiaChi(), x.getDiemTichLuy(), x.getGioiTinh());
            listKhachHang.add(khachHang);
        }
        return listKhachHang;
    }

    @Override
    public QLKhachHang getOne(String ma) {
        KhachHang kh = khachHangRep.getOne(ma);
        QLKhachHang qlkh = new QLKhachHang(kh.getId(), kh.getCccd(), kh.getNamSinh(), kh.getSdt(), kh.getEmail(),
                kh.getDiaChi(), kh.getDiemTichLuy(), kh.getGioiTinh());
        return qlkh;       
    }
    
}
