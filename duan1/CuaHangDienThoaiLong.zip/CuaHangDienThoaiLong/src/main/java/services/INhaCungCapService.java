/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package services;

import java.util.List;
import viewModel.QLNhaCungCap;

/**
 *
 * @author Admin
 */
public interface INhaCungCapService {
    
    List<QLNhaCungCap> getAll();
    
    String save(QLNhaCungCap ncc);
    
    String update(QLNhaCungCap ncc);
    
    String delete(QLNhaCungCap ncc);
    
}
